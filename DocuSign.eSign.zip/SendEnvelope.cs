﻿using DocuSign.eSign.Api;
using DocuSign.eSign.Client;
using DocuSign.eSign.Client.Auth;
using DocuSign.eSign.Model;
//using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Text;

namespace DocusignAssembly
{
    public class SendEnvelope : CodeActivity
    {
        [Input("FileContent")]
        [RequiredArgument]
        public InArgument<string> FileContent
        {
            get;
            set;
        }
        [Input("FileName")]
        [RequiredArgument]
        public InArgument<string> FileName
        {
            get;
            set;
        }
        [Input("ClientID")]
        [RequiredArgument]
        public InArgument<string> ClientID
        {
            get;
            set;
        }



        [Input("ImpersonatedUserGuid")]
        [RequiredArgument]
        public InArgument<string> ImpersonatedUserGuid
        {
            get;
            set;
        }
        [Input("AuthServer")]
        [RequiredArgument]
        public InArgument<string> AuthServer
        {
            get;
            set;
        }
       

        [Input("basePath")]
        [RequiredArgument]
        public InArgument<string> basePath
        {
            get;
            set;
        }

        [Input("accountId")]
        [RequiredArgument]
        public InArgument<string> accountId
        {
            get;
            set;
        }
        [Input("signerEmail")]
        [RequiredArgument]
        public InArgument<string> signerEmail
        {
            get;
            set;
        }

        [Input("signerName")]
        [RequiredArgument]
        public InArgument<string> signerName
        {
            get;
            set;
        }

        [Input("signer1Email")]
        public InArgument<string> signer1Email
        {
            get;
            set;
        }

        [Input("signer1Name")]
        public InArgument<string> signer1Name
        {
            get;
            set;
        }

        [Input("signer2Email")]
        public InArgument<string> signer2Email
        {
            get;
            set;
        }

        [Input("signer2Name")]
        public InArgument<string> signer2Name
        {
            get;
            set;
        }

        [Output("EnvelopeId")]
        public OutArgument<string> EnvelopeId
        {
            get;
            set;
        }
        string key =  @"-----BEGIN RSA PRIVATE KEY-----
 MIIEoQIBAAKCAQEAs/KKyXeAy9hxE2mY+FZJqUy1F+8Bo9Pqj326FiEORhgf16Da
 x7m35Tbz0T/r9uAcOtECvElOzdXyiv5/ljfXzNNGYgqo8YVeODPQljwSy7isLZwe
 NbzpwSNzhRRFij4xOEiA19wncy7MA5mRYeVw5UL/SyWEn+xUY0kJNESzt3u0KJH1
 R02LQo3eFZrFkggskU1E/TzGCrPPNEVlmVNRwVv4i4eH6+YMFReFP3O0Nez4ADhK
 DRlfH6P+zVdoQdT7SsxAVss7lLEQL04EsiVbUQo4HBWGE5fsXYlusPgjxz27Wo3A
 qnmgP5XlEauHpvjVSCkpDDePnM2ag63cBa8+PQIDAQABAoH/HKS+8tLS7Z/GYBCv
 CNizYP+U0/p3iFxzOeQJevxICWBNsUUpjiFB5Hqa1PQX23RRCgu7I72HjbxAn19j
 b8Xz0+bNjU2lFszj8o5M5Z0qYMNEpP300RkBHH1IJibT6u17aDoiSDoDDZKlZu1K
 9wpOri+783pFYi98P1Gg5XEKKmqBnpvGIXPbOCtHSjnb6DALvt7xPR86wXY9QSA+
 b4LS6yzVgeykxm/GvosOy0UseeGZNHMK4F0SpixBxCBbASGmV1p5tt7nuHWnZ0yD
 53xQephSdzO2ai6JSAhklniEUi0k73B1C0d0r1J5/i/UObf0RkVPX+cMXwnAWB35
 3ECBAoGBAPP76sNpOCotNsU9UVfQA/pDqd8jZk4jjfUiO7XlyTFpFKFnddtrSzXu
 TEkGD1RRKwxerodU+nm7mGTsvgX8V1o96DaIYOHrFuNVqF96vk96W6Y3v8e9WkK5
 YMcEOyRntQV5EHIYKESdlpVHj6W9WGnGD1DF/ZaiHFUvHOuf9NW9AoGBALzPROtC
 vxSd0Z0HYA0eYrnKPCGg5M17JeIilwv6LvmF1Kxfsn2z7cCZAeCVkI12eTTn6ZSy
 bb4MHwnFD/tdIZGEO5IEx9UpqqtaupKqDCbC1YNgQccGznYLYauhB7oBqFbyPZbr
 7Nfux1QXnDdF/YZAS5JBv/QeRbQCJ0VZTVKBAoGAKG0mYgiOKNbjC110m/M4pYAO
 po1sByh2/hYVBLe1VX2O0IufCKNHjAEXHMZnRdZJJryNeJkJA6CkyJw9hCpiou49
 CsQgIW7dlP99bYyd+fdRNkJogYULbqDeuzslPYv9f5GmuvDrwyrFZ6i60YCFJMmP
 ghe8Q/hKb4bl6NjRLZUCgYADsvvisBgWS1FEBlT3bNT6Vt/+uKxC6lq/p3XWIjyx
 XtHf3rAcjl3mHBlRURzX6K5PPwvwgd5sjsg85MN/ZT+3HiQcpENWBc72NHzbSsGa
 MM8GF+iyAYwh++8Z8bm5BzdJHM3gGxc009TL7Pp+iryA2NmiL++W1NEAydoDHdDK
 AQKBgQCt/q/7MBYUyLYfn3uxTbyIKxTYkWLvTWCnZX/ZR0Dt+TL6hFf1l40XBt+R
 fYPn6pOM/RxJnbHC/52n2W6/4RP6BieWN8dPb5eiGOa0Eyijx1lIxqDhe66f+VP0
 CfvLng+yjCsPKULt3yXVpfVciJli2f05rk5ulZHMiNaZrurA8g==
 -----END RSA PRIVATE KEY-----";
        public string OnPostAsync(CodeActivityContext executionContext)
        {
            ApiClient client = new ApiClient();
            OAuth.OAuthToken authToken = client.RequestJWTUserToken(ClientID.Get(executionContext),
                           ImpersonatedUserGuid.Get(executionContext),
                           AuthServer.Get(executionContext),
                           Encoding.UTF8.GetBytes(key),
                           1);

           string AccessToken = authToken.access_token;
            Document document = new Document
            {
                DocumentBase64 = FileContent.Get(executionContext),
                Name = FileName.Get(executionContext),
                FileExtension = "pdf",
                DocumentId = "1"
            };
            Document[] documents = new Document[] { document };
            List<Signer> signers = new List<Signer>();
            // Create the signer recipient object 
            Signer signer = new Signer
            {
                Email = signerEmail.Get(executionContext),
                Name = signerName.Get(executionContext),
                RecipientId = "1",
                RoutingOrder = "1"
            };
            signers.Add(signer);
            if (signer1Email.Get(executionContext)!=null && signer1Name.Get(executionContext)!=null)
            {
                Signer Signer1 = new Signer
                {
                    Email = signer1Email.Get(executionContext),
                    Name = signer1Name.Get(executionContext),
                    RecipientId = "2",
                    RoutingOrder = "2"
                };
                signers.Add(Signer1);
            }
            if (signer2Email.Get(executionContext) != null && signer2Name.Get(executionContext) != null)
            {
                Signer Signer2 = new Signer
                {
                    Email = signer2Email.Get(executionContext),
                    Name = signer2Name.Get(executionContext),
                    RecipientId = "3",
                    RoutingOrder = "3"
                };
                signers.Add(Signer2);
            }
            // Create the sign here tab (signing field on the document)
            SignHere signHereTab = new SignHere
            {
                DocumentId = "1",
                PageNumber = "1",
                RecipientId = "1",
                TabLabel = "Sign Here Tab",
                XPosition = "400",
                YPosition = "650"
            };
            SignHere[] signHereTabs = new SignHere[] { signHereTab };

            // Add the sign here tab array to the signer object.
            signer.Tabs = new Tabs { SignHereTabs = new List<SignHere>(signHereTabs) };
            // Create array of signer objects
            // Create recipients object
            Recipients recipients = new Recipients { Signers = new List<Signer>(signers) };
            // Bring the objects together in the EnvelopeDefinition
            EnvelopeDefinition envelopeDefinition = new EnvelopeDefinition
            {
                EmailSubject = "Please sign the document",

                Documents = new List<Document>(documents),
                Recipients = recipients,
                Status = "sent"
            };

            // 2. Use the SDK to create and send the envelope
            ApiClient apiClient = new ApiClient(basePath.Get(executionContext));
            apiClient.Configuration.AddDefaultHeader("Authorization", "Bearer " + AccessToken);
            EnvelopesApi envelopesApi = new EnvelopesApi(apiClient.Configuration);
            EnvelopeSummary results = envelopesApi.CreateEnvelope(accountId.Get(executionContext), envelopeDefinition);
            string Docusignresults = results.EnvelopeId;

            return Docusignresults;
        }

        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            //ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            ////Create the context
            //IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            //IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            //IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                string result = OnPostAsync(executionContext);
                EnvelopeId.Set(executionContext,result);

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }
    }
}
